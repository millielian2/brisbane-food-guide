Image folder for Brisbane Food Guide. Filenames are matched to the current script.js naming convention.
